package com.ExcelIsland.backend.entity;

import lombok.*;

@Data
@Getter
@Setter
public class Admin extends User{
}
